This directory is intended to contain Hazelcast [1] JARs for Maven Resolver Named Locks using Hazelcast.

See here [2] on how to add necessary JARs.

[1] https://github.com/hazelcast/hazelcast
[2] https://maven.apache.org/resolver/maven-resolver-named-locks-hazelcast/index.html#installation-testing
